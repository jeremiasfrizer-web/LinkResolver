#!/usr/bin/env bash
set -euo pipefail
PKG=com.linkresolver.app
adb install -r LinkResolver.apk
adb shell pm list packages | grep -q "$PKG"
adb logcat -c
adb shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1
sleep 6
adb shell pidof "$PKG"
adb shell am start -a android.intent.action.SEND -t text/plain \
  --es android.intent.extra.TEXT "https://example.com" -n "$PKG/.MainActivity"
sleep 8
adb shell pidof "$PKG"
if adb logcat -d | grep -q "FATAL EXCEPTION"; then
  adb logcat -d | grep -A20 "FATAL EXCEPTION"
  exit 1
fi
adb uninstall "$PKG"
echo "Teste de instalação OK"
