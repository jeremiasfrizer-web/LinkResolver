# Link Resolver
Cada push em `main` roda: testes unitários → APK release assinado → verificação (apksigner/aapt2) → publicação em Releases.
Download direto: `https://github.com/<usuario>/<repo>/releases/latest/download/LinkResolver.apk`
Testes em emulador (Android 8.0 e 14): ui-tests e install-test.

Assinatura permanente (opcional): crie os secrets KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS e KEY_PASSWORD.
Sem eles, o build gera uma chave temporária (o APK instala normalmente; só não atualiza por cima de versão anterior).
