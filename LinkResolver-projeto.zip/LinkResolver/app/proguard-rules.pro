# sem regras extras: o app usa apenas HttpURLConnection e org.json
