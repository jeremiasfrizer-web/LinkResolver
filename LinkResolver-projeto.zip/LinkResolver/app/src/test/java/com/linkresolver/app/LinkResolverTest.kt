package com.linkresolver.app

import com.linkresolver.app.TinyServer.Reply
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class LinkResolverTest {
    private lateinit var server: TinyServer
    private val base get() = "http://127.0.0.1:${server.port}"

    private fun route(path: String): Reply = when {
        path == "/a" -> Reply(302, mapOf("Location" to "/b?x=1&y=2%20z"))
        path.startsWith("/b") -> Reply(301, mapOf("Location" to "$base/c?keep=1&y=2%20z"))
        path.startsWith("/c") -> Reply(200, mapOf("Content-Type" to "text/plain"), "ok")
        path == "/loop1" -> Reply(302, mapOf("Location" to "/loop2"))
        path == "/loop2" -> Reply(302, mapOf("Location" to "/loop1"))
        path == "/forbidden" -> Reply(403, mapOf("Content-Type" to "text/plain"), "no")
        path == "/nolocation" -> Reply(302)
        path == "/scheme" -> Reply(302, mapOf("Location" to "market://details?id=x"))
        path == "/meta" -> Reply(
            200, mapOf("Content-Type" to "text/html"),
            """<html><head><meta http-equiv="refresh" content="0; url=/c?m=1&amp;n=2"></head></html>"""
        )
        else -> Reply(404, mapOf("Content-Type" to "text/plain"), "nf")
    }

    @Before fun setUp() {
        server = TinyServer { route(it) }
        server.start()
    }

    @After fun tearDown() = server.stop()

    private fun resolve(url: String) = LinkResolver.resolve(url) { false }

    @Test fun followsChainAndPreservesQuery() {
        val r = resolve("$base/a")
        assertEquals(Status.RESOLVED, r.status)
        assertEquals("$base/c?keep=1&y=2%20z", r.finalUrl)
        assertEquals(listOf(302, 301, 200), r.hops.map { it.code })
    }

    @Test fun noRedirectIsUnchanged() {
        val r = resolve("$base/c")
        assertEquals(Status.UNCHANGED, r.status)
        assertEquals("$base/c", r.finalUrl)
    }

    @Test fun detectsLoop() {
        val r = resolve("$base/loop1")
        assertEquals(Status.ERROR, r.status)
        assertTrue(r.message!!.contains("Loop"))
    }

    @Test fun http403NeedsSession() {
        assertEquals(Status.NEEDS_SESSION, resolve("$base/forbidden").status)
    }

    @Test fun http404IsError() {
        val r = resolve("$base/does-not-exist")
        assertEquals(Status.ERROR, r.status)
        assertTrue(r.message!!.contains("404"))
    }

    @Test fun redirectWithoutLocationIsError() {
        assertEquals(Status.ERROR, resolve("$base/nolocation").status)
    }

    @Test fun nonWebSchemeIsReported() {
        val r = resolve("$base/scheme")
        assertEquals(Status.ERROR, r.status)
        assertTrue(r.message!!.contains("market"))
    }

    @Test fun followsMetaRefresh() {
        val r = resolve("$base/meta")
        assertEquals(Status.RESOLVED, r.status)
        assertEquals("$base/c?m=1&n=2", r.finalUrl)
    }

    @Test fun connectionRefusedIsError() {
        assertEquals(Status.ERROR, resolve("http://127.0.0.1:1/").status)
    }

    @Test fun cancellationStops() {
        assertEquals(Status.ERROR, LinkResolver.resolve("$base/a") { true }.status)
    }

    @Test fun extractUrl() {
        assertEquals("https://exemplo.com/a?b=1", LinkResolver.extractUrl("veja https://exemplo.com/a?b=1."))
        assertEquals("https://exemplo.com/x", LinkResolver.extractUrl("exemplo.com/x"))
        assertNull(LinkResolver.extractUrl("olá mundo"))
        assertNull(LinkResolver.extractUrl("   "))
    }

    @Test fun platoRelayRecognition() {
        assertTrue(PlatoRelayModule.isRelayHost("https://auth.platorelay.com/a?d=abc"))
        assertFalse(PlatoRelayModule.isRelayHost("https://evilplatorelay.com/a"))
        assertTrue(PlatoRelayModule.analyze("https://example.com/a?d=1").isEmpty())
        val notes = PlatoRelayModule.analyze("https://auth.platorelay.com/a?d=AbC123")
        assertTrue(notes.any { it.contains("\"d\"") && it.contains("6 caracteres") })
        assertFalse(notes.any { it.contains("AbC123") })
    }

    @Test fun platoRelayPlainUrlInDIsOnlyReported() {
        val notes = PlatoRelayModule.analyze("https://auth.platorelay.com/a?d=https%3A%2F%2Fexample.com%2Fx")
        assertTrue(notes.any { it.contains("https://example.com/x") })
    }
}
