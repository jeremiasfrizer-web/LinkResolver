package com.linkresolver.app

import java.io.IOException
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException

enum class Status { RESOLVED, UNCHANGED, NEEDS_BROWSER, NEEDS_SESSION, ERROR }

data class Hop(val url: String, val code: Int)

data class ResolveResult(
    val status: Status,
    val finalUrl: String?,
    val hops: List<Hop>,
    val notes: List<String>,
    val message: String? = null
)

/**
 * Segue redirecionamentos HTTP (301/302/303/307/308) e <meta http-equiv="refresh">
 * de forma passiva. Nunca executa JavaScript, não envia cookies/credenciais e
 * não tenta contornar autenticação.
 */
object LinkResolver {
    private const val MAX_HOPS = 10
    private const val MAX_BODY_BYTES = 64 * 1024
    private const val TIMEOUT_MS = 10_000
    private const val USER_AGENT = "LinkResolver/1.0 (Android)"

    private val urlRegex = Regex("""https?://[^\s<>"']+""", RegexOption.IGNORE_CASE)
    private val schemeRegex = Regex("""^\s*([a-zA-Z][a-zA-Z0-9+.-]*):""")
    private val metaRefresh = Regex(
        """<meta[^>]+http-equiv\s*=\s*["']?refresh["']?[^>]*content\s*=\s*["']?\s*\d+\s*;\s*url\s*=\s*['"]?([^"'>\s]+)""",
        RegexOption.IGNORE_CASE
    )

    fun extractUrl(text: String): String? {
        val t = text.trim()
        urlRegex.find(t)?.let { return it.value.trimEnd('.', ',', ';', ')') }
        if (t.isNotEmpty() && !t.contains(' ') && t.contains('.') && !t.contains("://")) return "https://$t"
        return null
    }

    private sealed class Step {
        data class Next(val url: String, val code: Int) : Step()
        data class Done(val code: Int) : Step()
        data class Fail(val code: Int, val status: Status, val msg: String) : Step()
    }

    fun resolve(raw: String, cancelled: () -> Boolean): ResolveResult {
        val start = extractUrl(raw)
            ?: return ResolveResult(Status.ERROR, null, emptyList(), emptyList(), "Nenhum link válido encontrado.")

        val hops = mutableListOf<Hop>()
        val notes = mutableListOf<String>()
        notes.addAll(PlatoRelayModule.analyze(start))

        val seen = HashSet<String>()
        var current = start

        try {
            while (true) {
                if (cancelled()) return ResolveResult(Status.ERROR, null, hops, notes, "Cancelado.")
                if (!seen.add(current)) {
                    return ResolveResult(Status.ERROR, null, hops, notes, "Loop de redirecionamento detectado.")
                }
                if (hops.size >= MAX_HOPS) {
                    return ResolveResult(Status.ERROR, null, hops, notes, "Redirecionamentos demais (limite: $MAX_HOPS).")
                }
                when (val step = step(current)) {
                    is Step.Next -> {
                        hops.add(Hop(current, step.code))
                        if (current.startsWith("https://", true) && step.url.startsWith("http://", true)) {
                            notes.add("Atenção: um redirecionamento saiu de HTTPS para HTTP (sem criptografia).")
                        }
                        current = step.url
                    }
                    is Step.Done -> {
                        hops.add(Hop(current, step.code))
                        return finish(start, current, hops, notes)
                    }
                    is Step.Fail -> {
                        if (step.code > 0) hops.add(Hop(current, step.code))
                        return ResolveResult(step.status, if (step.status == Status.ERROR) null else current, hops, notes, step.msg)
                    }
                }
            }
        } catch (e: UnknownHostException) {
            return ResolveResult(Status.ERROR, null, hops, notes, "Sem conexão ou domínio não encontrado.")
        } catch (e: SocketTimeoutException) {
            return ResolveResult(Status.ERROR, null, hops, notes, "Tempo esgotado ao acessar o servidor.")
        } catch (e: SSLException) {
            return ResolveResult(Status.ERROR, null, hops, notes, "Falha de segurança SSL/TLS: ${e.message ?: "certificado inválido"}.")
        } catch (e: MalformedURLException) {
            return ResolveResult(Status.ERROR, null, hops, notes, "URL malformada.")
        } catch (e: IOException) {
            return ResolveResult(Status.ERROR, null, hops, notes, "Erro de rede: ${e.message ?: "desconhecido"}.")
        }
    }

    private fun step(current: String): Step {
        val conn = URL(current).openConnection() as HttpURLConnection
        try {
            conn.instanceFollowRedirects = false
            conn.connectTimeout = TIMEOUT_MS
            conn.readTimeout = TIMEOUT_MS
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", USER_AGENT)
            conn.setRequestProperty("Accept", "text/html,*/*;q=0.8")
            val code = conn.responseCode

            return when (code) {
                301, 302, 303, 307, 308 -> {
                    val loc = conn.getHeaderField("Location")
                        ?: return Step.Fail(code, Status.ERROR, "Redirecionamento sem cabeçalho Location.")
                    val scheme = schemeRegex.find(loc)?.groupValues?.get(1)
                    if (scheme != null && !scheme.equals("http", true) && !scheme.equals("https", true)) {
                        Step.Fail(code, Status.ERROR, "O destino usa o esquema \"$scheme://\" (provavelmente abre um app), que não é um link web.")
                    } else {
                        Step.Next(URL(URL(current), loc).toString(), code)
                    }
                }
                401, 403 -> Step.Fail(
                    code, Status.NEEDS_SESSION,
                    "O servidor exige uma sessão/autenticação legítima (HTTP $code). Abra o link no navegador e conclua o processo por lá."
                )
                in 200..299 -> {
                    val type = conn.contentType.orEmpty().lowercase()
                    if (type.contains("html")) {
                        val html = conn.inputStream.use { ins ->
                            val buf = ByteArray(MAX_BODY_BYTES)
                            var n = 0
                            while (n < buf.size) {
                                val r = ins.read(buf, n, buf.size - n)
                                if (r < 0) break
                                n += r
                            }
                            String(buf, 0, n, Charsets.UTF_8)
                        }
                        val m = metaRefresh.find(html)?.groupValues?.get(1)
                        if (m != null) {
                            val next = URL(URL(current), m.replace("&amp;", "&")).toString()
                            if (next.startsWith("http://", true) || next.startsWith("https://", true)) {
                                return Step.Next(next, code)
                            }
                        }
                    }
                    Step.Done(code)
                }
                else -> Step.Fail(code, Status.ERROR, "O servidor respondeu com HTTP $code.")
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun finish(start: String, finalUrl: String, hops: List<Hop>, notes: MutableList<String>): ResolveResult {
        if (PlatoRelayModule.isRelayHost(finalUrl)) {
            notes.add(
                "O serviço não emitiu redirecionamento HTTP para um destino externo. " +
                "A página final provavelmente exige interação ou sessão no navegador. " +
                "O app não executa scripts nem contorna etapas do serviço."
            )
            return ResolveResult(Status.NEEDS_BROWSER, finalUrl, hops, notes)
        }
        if (finalUrl == start) return ResolveResult(Status.UNCHANGED, finalUrl, hops, notes)
        return ResolveResult(Status.RESOLVED, finalUrl, hops, notes)
    }
}
