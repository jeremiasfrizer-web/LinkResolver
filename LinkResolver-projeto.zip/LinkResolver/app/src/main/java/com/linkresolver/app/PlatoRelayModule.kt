package com.linkresolver.app

import java.net.URL
import java.net.URLDecoder

/**
 * Reconhecimento de links PlatoRelay (auth.platorelay.com/a?d=...).
 *
 * LIMITAÇÃO: não há API pública/documentada conhecida do PlatoRelay para obter o destino
 * a partir de "d". Este módulo NÃO decodifica "d" (não assume Base64 nem outro formato) e
 * NÃO contorna autenticação. Ele reconhece o link, descreve os parâmetros de forma neutra e
 * deixa o resolvedor genérico seguir apenas redirecionamentos HTTP legítimos.
 */
object PlatoRelayModule {
    private const val BASE = "platorelay.com"

    private fun hostOf(url: String): String? = try {
        URL(url).host?.lowercase()?.takeIf { it.isNotEmpty() }
    } catch (e: Exception) {
        null
    }

    fun isRelayHost(url: String): Boolean {
        val host = hostOf(url) ?: return false
        return host == BASE || host.endsWith(".$BASE")
    }

    fun analyze(url: String): List<String> {
        if (!isRelayHost(url)) return emptyList()
        val u = URL(url)
        val notes = mutableListOf("Link PlatoRelay reconhecido (host ${u.host}, caminho ${u.path.ifEmpty { "/" }}).")
        val query = u.query
        if (query.isNullOrEmpty()) {
            notes.add("Nenhum parâmetro de consulta encontrado.")
            return notes
        }
        for (pair in query.split('&').filter { it.isNotEmpty() }) {
            val name = decode(pair.substringBefore('='))
            val value = decode(pair.substringAfter('=', ""))
            notes.add("Parâmetro \"$name\": ${value.length} caracteres, formato opaco (não decodificado).")
            // Apenas informa se o valor, em texto simples, já for uma URL. Não é usado como destino.
            if (name == "d" && (value.startsWith("http://", true) || value.startsWith("https://", true))) {
                notes.add("O parâmetro \"d\" contém uma URL em texto simples: $value")
            }
        }
        return notes
    }

    private fun decode(s: String): String = try {
        URLDecoder.decode(s, "UTF-8")
    } catch (e: Exception) {
        s
    }
}
