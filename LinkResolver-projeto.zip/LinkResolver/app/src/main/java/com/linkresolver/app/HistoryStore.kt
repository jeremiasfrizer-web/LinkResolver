package com.linkresolver.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val original: String, val resolved: String, val status: String, val time: Long)

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("history", Context.MODE_PRIVATE)

    fun load(): List<HistoryEntry> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryEntry(o.getString("o"), o.getString("r"), o.getString("s"), o.getLong("t"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun add(entry: HistoryEntry) {
        val list = (listOf(entry) + load().filter { it.original != entry.original }).take(50)
        save(list)
    }

    fun clear() = prefs.edit().remove("items").apply()

    private fun save(list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("o", it.original).put("r", it.resolved).put("s", it.status).put("t", it.time))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
