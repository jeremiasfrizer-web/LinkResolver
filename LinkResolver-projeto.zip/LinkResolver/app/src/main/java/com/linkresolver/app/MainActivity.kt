package com.linkresolver.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var ticket = 0

    private lateinit var history: HistoryStore
    private lateinit var input: EditText
    private lateinit var btnResolve: MaterialButton
    private lateinit var progress: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var resultCard: View
    private lateinit var resultStatus: TextView
    private lateinit var resultUrl: TextView
    private lateinit var resultDetails: TextView
    private lateinit var historyList: LinearLayout
    private lateinit var historyEmpty: TextView
    private var lastResolved: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        history = HistoryStore(this)

        input = findViewById(R.id.inputUrl)
        btnResolve = findViewById(R.id.btnResolve)
        progress = findViewById(R.id.progress)
        errorText = findViewById(R.id.errorText)
        resultCard = findViewById(R.id.resultCard)
        resultStatus = findViewById(R.id.resultStatus)
        resultUrl = findViewById(R.id.resultUrl)
        resultDetails = findViewById(R.id.resultDetails)
        historyList = findViewById(R.id.historyList)
        historyEmpty = findViewById(R.id.historyEmpty)

        findViewById<View>(R.id.btnPaste).setOnClickListener { pasteFromClipboard() }
        btnResolve.setOnClickListener { startResolve() }
        findViewById<View>(R.id.btnCopy).setOnClickListener { copyResult() }
        findViewById<View>(R.id.btnClearHistory).setOnClickListener {
            history.clear(); renderHistory()
        }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { startResolve(); true } else false
        }

        renderHistory()
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(incoming: Intent?) {
        val i = incoming ?: return
        val text = when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i.data?.toString()
            else -> null
        }
        if (!text.isNullOrBlank()) {
            input.setText(text.trim())
            startResolve()
        }
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString() else null
        if (text.isNullOrBlank()) toast(getString(R.string.clipboard_empty)) else input.setText(text.trim())
    }

    private fun startResolve() {
        val text = input.text.toString()
        if (text.isBlank()) { showError(getString(R.string.enter_link)); return }
        val my = ++ticket
        setLoading(true)
        executor.execute {
            val result = LinkResolver.resolve(text) { my != ticket }
            ui.post { if (my == ticket) showResult(text.trim(), result) }
        }
    }

    private fun setLoading(on: Boolean) {
        progress.visibility = if (on) View.VISIBLE else View.GONE
        btnResolve.isEnabled = !on
        if (on) { errorText.visibility = View.GONE; resultCard.visibility = View.GONE }
    }

    private fun showError(msg: String) {
        setLoading(false)
        resultCard.visibility = View.GONE
        errorText.text = msg
        errorText.visibility = View.VISIBLE
    }

    private fun showResult(original: String, r: ResolveResult) {
        setLoading(false)
        if (r.status == Status.ERROR) { showError(r.message ?: getString(R.string.unknown_error)); return }

        val label = when (r.status) {
            Status.RESOLVED -> getString(R.string.st_resolved)
            Status.UNCHANGED -> getString(R.string.st_unchanged)
            Status.NEEDS_BROWSER -> getString(R.string.st_needs_browser)
            Status.NEEDS_SESSION -> getString(R.string.st_needs_session)
            Status.ERROR -> ""
        }
        lastResolved = r.finalUrl
        resultStatus.text = label
        resultUrl.text = r.finalUrl
        val sb = StringBuilder()
        r.message?.let { sb.append(it).append("\n\n") }
        r.notes.forEach { sb.append("• ").append(it).append('\n') }
        if (r.hops.isNotEmpty()) {
            sb.append("\n").append(getString(R.string.path)).append('\n')
            r.hops.forEachIndexed { i, h -> sb.append("${i + 1}. [${h.code}] ${h.url}\n") }
        }
        resultDetails.text = sb.toString().trim()
        resultCard.visibility = View.VISIBLE

        r.finalUrl?.let { history.add(HistoryEntry(original, it, label, System.currentTimeMillis())) }
        renderHistory()
    }

    private fun copyResult() {
        val url = lastResolved ?: return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Link", url))
        toast(getString(R.string.copied))
    }

    private fun renderHistory() {
        historyList.removeAllViews()
        val items = history.load()
        historyEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        val pad = dp(10)
        val outValue = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, outValue, true)
        for (e in items) {
            val tv = TextView(this).apply {
                text = "${e.resolved}\n${df.format(Date(e.time))} · ${e.status}"
                setPadding(0, pad, 0, pad)
                setBackgroundResource(outValue.resourceId)
                textSize = 13f
                setOnClickListener { input.setText(e.original) }
            }
            historyList.addView(tv)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        ticket++
        executor.shutdownNow()
        super.onDestroy()
    }
}
