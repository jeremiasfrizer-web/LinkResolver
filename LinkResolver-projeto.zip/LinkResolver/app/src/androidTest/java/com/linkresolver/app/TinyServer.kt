package com.linkresolver.app

import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket

/** Servidor HTTP minúsculo para testes: uma resposta por requisição, em 127.0.0.1. */
class TinyServer(private val route: (String) -> Reply) {
    class Reply(val code: Int, val headers: Map<String, String> = emptyMap(), val body: String = "")

    private val ss = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
    @Volatile private var running = true
    val port: Int get() = ss.localPort

    fun start() {
        Thread {
            while (running) {
                try {
                    val s = ss.accept()
                    Thread { handle(s) }.start()
                } catch (e: Exception) {
                    break
                }
            }
        }.start()
    }

    fun stop() {
        running = false
        ss.close()
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            val reader = s.getInputStream().bufferedReader()
            val line = reader.readLine() ?: return
            var h = reader.readLine()
            while (!h.isNullOrEmpty()) h = reader.readLine()
            val path = line.split(" ").getOrElse(1) { "/" }
            val rep = route(path)
            val body = rep.body.toByteArray()
            val sb = StringBuilder("HTTP/1.1 ${rep.code} X\r\n")
            rep.headers.forEach { (k, v) -> sb.append("$k: $v\r\n") }
            sb.append("Content-Length: ${body.size}\r\nConnection: close\r\n\r\n")
            val out = s.getOutputStream()
            out.write(sb.toString().toByteArray())
            out.write(body)
            out.flush()
        }
    }
}
