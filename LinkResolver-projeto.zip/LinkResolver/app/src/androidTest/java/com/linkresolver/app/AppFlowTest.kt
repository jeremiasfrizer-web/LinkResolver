package com.linkresolver.app

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.replaceText
import androidx.test.espresso.action.ViewActions.scrollTo
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.linkresolver.app.TinyServer.Reply
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AppFlowTest {
    private lateinit var server: TinyServer
    private val base get() = "http://127.0.0.1:${server.port}"

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        ctx.getSharedPreferences("history", Context.MODE_PRIVATE).edit().clear().commit()
        server = TinyServer { path ->
            when {
                path.startsWith("/s") -> Reply(302, mapOf("Location" to "$base/final?ok=1&q=a%20b"))
                path.startsWith("/final") -> Reply(200, mapOf("Content-Type" to "text/plain"), "ok")
                else -> Reply(404)
            }
        }
        server.start()
    }

    @After fun tearDown() = server.stop()

    private fun shareIntent(text: String) =
        Intent(ApplicationProvider.getApplicationContext(), MainActivity::class.java)
            .setAction(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)

    private fun waitUntil(sc: ActivityScenario<MainActivity>, cond: (MainActivity) -> Boolean) {
        repeat(150) {
            var ok = false
            sc.onActivity { ok = cond(it) }
            if (ok) return
            Thread.sleep(100)
        }
        fail("Tempo esgotado esperando a condição na interface")
    }

    private fun MainActivity.shown(id: Int) = findViewById<View>(id).visibility == View.VISIBLE

    @Test fun appStarts() {
        ActivityScenario.launch(MainActivity::class.java).use { sc ->
            sc.onActivity { assertEquals(View.VISIBLE, it.findViewById<View>(R.id.btnResolve).visibility) }
        }
    }

    @Test fun sharedLinkIsResolvedAutomatically_andSavedToHistory() {
        ActivityScenario.launch<MainActivity>(shareIntent("olha isso $base/s")).use { sc ->
            waitUntil(sc) { it.shown(R.id.resultCard) }
            sc.onActivity {
                assertEquals("$base/final?ok=1&q=a%20b", it.findViewById<TextView>(R.id.resultUrl).text.toString())
                assertEquals(1, it.findViewById<LinearLayout>(R.id.historyList).childCount)
            }
        }
    }

    @Test fun manualInput_resolve_andCopy() {
        ActivityScenario.launch(MainActivity::class.java).use { sc ->
            onView(withId(R.id.inputUrl)).perform(replaceText("$base/s"))
            onView(withId(R.id.btnResolve)).perform(click())
            waitUntil(sc) { it.shown(R.id.resultCard) }
            onView(withId(R.id.btnCopy)).perform(scrollTo(), click())
            sc.onActivity {
                val cm = it.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                assertEquals("$base/final?ok=1&q=a%20b", cm.primaryClip?.getItemAt(0)?.text?.toString())
            }
        }
    }

    @Test fun errorIsShown() {
        ActivityScenario.launch(MainActivity::class.java).use { sc ->
            onView(withId(R.id.inputUrl)).perform(replaceText("http://127.0.0.1:1/"))
            onView(withId(R.id.btnResolve)).perform(click())
            waitUntil(sc) { it.shown(R.id.errorText) }
        }
    }
}
